Neccesary Folders: PrepSys, Sysprep, Extra

Syntax-
Prepsys.exe [/r] [/t] [/r] [/s=settingsfile.ini] [/u] [/p] [d]

/r - Autorun prepsys

/s - settings file to use
	ex. /s=settingsfile.ini uses the settingsfile.ini in @ScriptDir/settings/
	ex. /s=D:\settingsfile.ini uses settingsfile.ini in D:\
	ex. /s=\\share\settingsfile.ini /u=username /p=password /d=domain
/u - Settings File Network Username(only needed if settings file is on network)
/p - Settings File Network Password(only needed if settings file is on network)
/d - Settings File Network Domain(only needed if settings file is on network)

/? - Shows README.txt file
/t - Opens to a specific tab
	ex. /t=1 ;General Tab
	ex. /t=2 ;Join Domain Tab
	ex. /t=3 ;Start Menu Tab
	ex. /t=4 ;Visual Tab
	ex. /t=5 ;Folder Tab
	ex. /t=6 ;Programs Tab
	ex. /t=7 ;Extra Program(s) Tab