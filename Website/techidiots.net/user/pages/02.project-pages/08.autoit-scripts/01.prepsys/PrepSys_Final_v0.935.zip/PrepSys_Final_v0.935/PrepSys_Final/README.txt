Neccesary Folders: PrepSys, Sysprep, Extra

Syntax-
Prepsys.exe [/r] [/t] [/r] [/s=settingsfile.ini]

/r - Autorun prepsys

/s - settings file to use
	ex. /s=settingsfile.ini uses the settingsfile.ini in @ScriptDir/settings/
	ex. /s=D:\settingsfile.ini uses settingsfile.ini in D:\
	ex. /s=\\share\settingsfile.ini
/? - Shows README.txt file
/t - Opens to a specific tab
	ex. /t=1 ;General Tab
	ex. /t=2 ;Join Domain Tab
	ex. /t=3 ;Start Menu Tab
	ex. /t=4 ;Visual Tab
	ex. /t=5 ;Folder Tab
	ex. /t=6 ;Programs Tab
	ex. /t=7 ;Extra Program(s) Tab