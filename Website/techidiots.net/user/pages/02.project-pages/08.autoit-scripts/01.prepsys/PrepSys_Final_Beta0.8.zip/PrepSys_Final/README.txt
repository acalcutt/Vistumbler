Neccesary Folders: PrepSys, Sysprep

Syntax-
Prepsys.exe [/r] [/s=settingsfile.ini]

/r - Autorun prepsys
/s - settings file to use
	ex. /s=settingsfile.ini uses the settingsfile.ini in @ScriptDir/settings/
	ex. /s=D:\settingsfile.ini uses settingsfile.ini in D:\
/? - Shows README.txt file