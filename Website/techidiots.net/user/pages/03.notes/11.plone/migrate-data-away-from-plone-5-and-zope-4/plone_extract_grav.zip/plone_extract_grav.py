import os
import datetime
from plone import api
from Products.CMFCore.utils import getToolByName
from bs4 import BeautifulSoup
import transaction
import sys
from Products.CMFPlone.interfaces import IPloneSiteRoot
from Zope2 import app
import time
import pytz
import re
import json


def extract_website_structure(portal, output_dir, site_id):
  """
  Extracts the website structure including content and URLs and outputs it as a JSON, and exports file to a folder
  """
  site_output_dir = os.path.join(output_dir, site_id)
  os.makedirs(site_output_dir, exist_ok=True)
    
  structure = {
    "site_id": site_id,
    "pages": []
  }

  catalog = portal.portal_catalog
  brains = catalog(portal_type=["Image", "File", "Document"])

  for brain in brains:
    try:
      obj = brain.getObject()
      modified_date = obj.modified()
        
      page_info = {
        "title": brain.Title if hasattr(brain, 'Title') else None,
        "url": brain.getURL() if hasattr(brain, 'getURL') else None,
        "path": "/".join(brain.getPath().split("/")[2:]) if hasattr(brain, 'getPath') else None,
        "portal_type": brain.portal_type if hasattr(brain, 'portal_type') else None,
        "modified_date": str(modified_date) if modified_date else None,
        "id": brain.id if hasattr(brain,'id') else None
      }

      if brain.portal_type == "Document":
        text_content = None
        if hasattr(obj, "text"):
          if hasattr(obj.text,'output'):
            text_content = obj.text.output
        if text_content:
            page_info["content"] = text_content
        else:
          if hasattr(obj,'text'):
            text_content = obj.text.raw
          if text_content:
            page_info["content"] = text_content
      elif brain.portal_type == "Image":
        if hasattr(obj,'image') and obj.image is not None:
          file_data = obj.image.data
          filename = obj.image.filename
          if file_data and filename:
            safe_filename = "".join(c if c.isalnum() or c in ['.','-','_'] else "_" for c in filename)
            new_filename = safe_filename
            output_path = os.path.join(site_output_dir, "files","images", page_info["path"] if 'path' in page_info and page_info["path"] else "" , new_filename)
            if os.path.basename(os.path.dirname(output_path)) == os.path.splitext(new_filename)[0]:
                output_path = os.path.join(site_output_dir, "files", "images", os.path.dirname(os.path.dirname(output_path)), new_filename)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'wb') as f:
              f.write(file_data)
            if modified_date:
              if modified_date:
                  os.utime(output_path, (modified_date, modified_date))
                  print(f"Saved Image: {output_path} ({brain.getURL()}) with modified_date {modified_date}")
            page_info["file_name"] = obj.image.filename if hasattr(obj.image,"filename") else None
            page_info["file_path"] = os.path.relpath(output_path,site_output_dir) if output_path else None#make relative
      elif brain.portal_type == "File":
        if hasattr(obj,'file') and obj.file is not None:
          file_data = obj.file.data
          filename = obj.file.filename
          if file_data and filename:
            safe_filename = "".join(c if c.isalnum() or c in ['.','-','_'] else "_" for c in filename)
            new_filename = safe_filename
            output_path = os.path.join(site_output_dir, "files", "files", page_info["path"] if 'path' in page_info and page_info["path"] else "", new_filename)
            if os.path.basename(os.path.dirname(output_path)) == os.path.splitext(new_filename)[0]:
                output_path = os.path.join(site_output_dir, "files", "files", os.path.dirname(os.path.dirname(output_path)), new_filename)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'wb') as f:
              f.write(file_data)
            if modified_date:
              if modified_date:
                os.utime(output_path, (modified_date, modified_date))
                print(f"Saved File: {output_path} ({brain.getURL()}) with modified_date {modified_date}")
            page_info["file_name"] = obj.file.filename if hasattr(obj.file,'filename') else None
            page_info["file_path"] = os.path.relpath(output_path,site_output_dir) if output_path else None #make relative
      structure["pages"].append(page_info)
    except Exception as e:
      print(f"Error processing {brain.getURL()}: {e}")
      transaction.abort()
  return structure

def list_plone_sites():
  """
  Lists the Plone sites and their IDs within a Zope instance.
  """
  try:
    root = app()
    output_dir = 'plone_export'
    os.makedirs(output_dir, exist_ok=True)
    for key in root.keys():
      item = root.get(key)
      if IPloneSiteRoot.providedBy(item):
        try:
            if hasattr(item, "absolute_url"):
              item_url = item.absolute_url()
              print(f"Extracting structure from Plone Site: {item.id}")
              site_structure = extract_website_structure(item, output_dir, item.id)
              output_file = f'{output_dir}/{item.id}/plone_structure_{item.id}.json'
              with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(site_structure, f, indent=4)
              print(f"Website structure saved to {output_file}")
        except Exception as e:
          print(f"Skipping {key} due to error getting site url: {e}")

      else:
        print(f"Skipping {key} as it is not a Plone Site")

  except Exception as e:
    print(f"Error accessing Zope root object: {e}")


if __name__ == '__main__':
  list_plone_sites()
  print("Website structure extraction complete.")
  